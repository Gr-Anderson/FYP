plot
----

.. automodule:: wfdb.plot
    :members: plot_items, plot_wfdb, plot_all_records
